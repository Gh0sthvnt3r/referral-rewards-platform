const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("ReferralRewards", () => {
  it("should register and increase referral count", async () => {
    const [referrer, referred] = await ethers.getSigners();
    const Contract = await ethers.getContractFactory("ReferralRewards");
    const contract = await Contract.deploy();
    await contract.register(referrer.address);
    const count = await contract.referralCounts(referrer.address);
    expect(count).to.equal(1);
  });
});
