const hre = require("hardhat");

async function main() {
  const ReferralRewards = await hre.ethers.getContractFactory("ReferralRewards");
  const contract = await ReferralRewards.deploy();
  await contract.deployed();
  console.log("ReferralRewards deployed to:", contract.address);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
