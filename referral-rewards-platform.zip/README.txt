# Referral Rewards Platform

## Structure
- **backend/**: Express API connected to MongoDB
- **frontend/**: React + Tailwind for user registration
- **smart-contract/**: Solidity smart contract (optional integration)

## Backend Setup
1. `cd backend`
2. Run `npm install`
3. Copy `.env.example` to `.env` and update Mongo URI
4. Start with `node app.js`

## Frontend Setup
1. `cd frontend`
2. Run `npm install`
3. Run `npm run dev` or `vite`

## Smart Contract (optional)
1. `cd smart-contract`
2. Run `npm install`
3. Deploy: `npx hardhat run scripts/deploy.js --network <your-network>`

## Hosting (Free)
- Backend: https://render.com/docs/deploy-node-express-app
- Frontend: https://docs.netlify.com/site-deploys/create-deploys/

Happy coding!
