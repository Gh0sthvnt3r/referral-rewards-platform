const express = require('express');
const router = express.Router();
const User = require('../models/User');

router.post('/register', async (req, res) => {
  const { email, referralId } = req.body;
  try {
    const existing = await User.findOne({ email });
    if (existing) return res.status(400).json({ message: 'Email already registered.' });

    const user = new User({ email });
    if (referralId) {
      const referrer = await User.findById(referralId);
      if (referrer) {
        user.referredBy = referralId;
        referrer.referrals.push(user._id);
        await referrer.save();
      }
    }
    await user.save();
    res.status(201).json({ message: 'Registered!', user });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
