import React, { useState } from 'react';
import axios from 'axios';

const RegisterForm = () => {
  const [email, setEmail] = useState('');
  const [referralId, setReferralId] = useState('');
  const [message, setMessage] = useState('');

  const handleRegister = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post('https://your-backend-url.onrender.com/api/users/register', { email, referralId });
      setMessage(res.data.message);
    } catch (err) {
      setMessage(err.response.data.message || 'Error occurred');
    }
  };

  return (
    <form onSubmit={handleRegister} className="p-4">
      <input type="email" placeholder="Email" className="block mb-2" value={email} onChange={e => setEmail(e.target.value)} required />
      <input type="text" placeholder="Referral ID (optional)" className="block mb-2" value={referralId} onChange={e => setReferralId(e.target.value)} />
      <button type="submit" className="bg-blue-500 text-white px-4 py-2">Register</button>
      {message && <p className="mt-2 text-green-600">{message}</p>}
    </form>
  );
};

export default RegisterForm;
